my.pwartest <- function(res, N, id,time,rho.H0, ...){
  res.1 <- c(NA,res[1:(N-1)])
  res.1[lagid!=0] <- NA
  data <- data.frame(id, time, res = unclass(res), res.1 = unclass(res.1))
  names(data)[c(1,2)] <- c("id","time")
  auxmod <- plm(res~res.1, data = data, model = "pooling", index = c("id", "time"))
  sumauxmode <- summary(auxmod)
  ## test H0: rho=rho.H0 with HAC t-test (HC0-3 parm may be passed)
  myvcov <- function(x) vcovHC(x, method="arellano")
  myH0 <- paste("res.1 = ", as.character(rho.H0), sep="")
  lhtest <- linearHypothesis(model=auxmod, myH0, vcov.=myvcov,test ="Chisq")
  #lhtest <- linearHypothesis(model=auxmod, myH0, test ="Chisq")
  ARstat <- lhtest[2,3]
  names(ARstat) <- dimnames(lhtest)[[2]][3]
  if (names(ARstat)=="Chisq") names(ARstat) <- "chisq"
  pAR <- lhtest[2,4]
  RVAL <- list(statistic = ARstat,
               method = "Wooldridge's test for serial correlation in FE panels",
               alternative = "serial correlation",
               p.value = pAR)
  class(RVAL) <- "htest"
#  return(sumauxmode)
  return(RVAL)
}



