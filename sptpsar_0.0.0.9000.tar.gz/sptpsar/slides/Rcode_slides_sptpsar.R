## ----setup, eval=FALSE, echo=FALSE---------------------------------------
## knitr::opts_chunk$set(echo = TRUE,warning=FALSE,error=FALSE)

## ------------------------------------------------------------------------
library(sptpsar)
 data(unemp_it); head(unemp_it)

## ------------------------------------------------------------------------
 form1 <- unrate ~ partrate + agri + cons +
                   pspl(serv,nknots=15) +
                   pspl(empgrowth,nknots=20)
 Wsp <- Wsp_it
 gamsar <- psar(form1,data=unemp_it,sar=TRUE,Wsp=Wsp_it)
 summary(gamsar)

## ----eval=FALSE----------------------------------------------------------
## ######################  Fit non-parametric terms
  list_varnopar <- c("serv","empgrowth")
  terms_nopar <- fit_terms(gamsar,list_varnopar)
## ######################  Plot non-parametric terms
  par(mar=c(1,1,1,1))
  plot_terms(terms_nopar,unemp_it)

## ------------------------------------------------------------------------
list_varpar <- c("partrate","agri","cons")
eff_parvar <- eff_par(gamsar,list_varpar)
summary(eff_parvar)

## ----eval=FALSE----------------------------------------------------------
 eff_nparvar <- eff_nopar(gamsar,list_varnopar)
 plot_effects_nopar(eff_nparvar,unemp_it,smooth=TRUE)
 plot_effects_nopar(eff_nparvar,unemp_it,smooth=FALSE)

## ------------------------------------------------------------------------
form2 <- unrate ~ partrate + agri + cons +
                 pspl(serv,nknots=15) + pspl(empgrowth,nknots=20) +
                 pspt(long,lat,nknots=c(20,20),psanova=FALSE)
geospsar <- psar(form2,data=unemp_it,Wsp=Wsp_it,sar=TRUE)
summary(geospsar)

## ---- eval=FALSE---------------------------------------------------------
 sptrend <- fit_terms(geospsar,"spttrend")
 n <- dim(unemp_it)[1]
 nT <- 19
 sp_seq <- seq(from=1,to=n,by=nT)
 lon <- scale(unemp_it[sp_seq,c("long")])
 lat <- scale(unemp_it[sp_seq,c("lat")])
 spt <- sptrend$fitted_terms[sp_seq]
 require(rgl); require(akima)
 akima_spt <- akima::interp(x=lon, y=lat, z=spt,
                            xo=seq(min(lon), max(lon), length = 1000),
                            yo=seq(min(lat), max(lat), length = 1000))
 open3d(); plot3d(x=lon,y=lat,z=spt)
 persp3d(akima_spt$x,akima_spt$y,akima_spt$z,
         xlim=range(lon),ylim=range(lat),
         zlim=range(spt),col="green3",aspect="iso",add=TRUE)
 movie3d(spin3d(axis = c(0,0,1), rpm = 10), duration=6,  type = "png")

## ------------------------------------------------------------------------
form3 <- unrate ~ partrate + agri + cons +
                   pspl(serv,nknots=15) + pspl(empgrowth,nknots=20) +
                   pspt(long,lat,nknots=c(18,18),psanova=TRUE,
                   nest_sp1=c(1,2),nest_sp2=c(1,2))
geospsaranova <- psar(form3,data=unemp_it,Wsp=Wsp_it,sar=TRUE)
summary(geospsaranova)

## ------------------------------------------------------------------------
form4 <- unrate ~ partrate + agri + cons +
                   pspl(serv,nknots=15) + pspl(empgrowth,nknots=20) +
                   pspt(long,lat,year,nknots=c(18,18,8),psanova=TRUE,
                   nest_sp1=c(1,2,3),nest_sp2=c(1,2,3),
                   nest_time=c(1,2,2),ntime=19)
sptanova <- psar(form4,data=unemp_it,sar=FALSE,
                  control=list(thr=1e-2,maxit=200))
summary(sptanova)

## ------------------------------------------------------------------------
sptsaranova <- psar(form4,data=unemp_it,sar=TRUE,Wsp=Wsp_it,
                  control=list(thr=1e-2,maxit=200))
summary(sptsaranova)

## ------------------------------------------------------------------------
sptsaranovaar1 <- psar(form4,data=unemp_it,sar=TRUE,ar1=TRUE,Wsp=Wsp_it,
                    control=list(thr=1e-1,maxit=200))
summary(sptsaranovaar1)

## ----eval=FALSE----------------------------------------------------------
spttrend <- fit_terms(sptsaranovaar1,"spttrend")
  lon <- scale(unemp_it$long); lat <- scale(unemp_it$lat)
  time <- unemp_it$year
##  ### Plot main effects
  plot_main_spt(spttrend,sp1=lon,sp2=lat,time=time,nT=19)

## ---- eval=FALSE---------------------------------------------------------
  list_varnopar <- c("serv","empgrowth")
  eff_nparvar <- eff_nopar(sptsaranovaar1,list_varnopar)
  plot_effects_nopar(eff_nparvar,unemp_it,smooth=TRUE)

## ------------------------------------------------------------------------
form5 <- unrate ~ partrate + agri + cons +
                   pspl(serv,nknots=15) + pspl(empgrowth,nknots=20) +
                   pspt(long,lat,year,nknots=c(18,18,8),psanova=TRUE,
                   nest_sp1=c(1,2,3),nest_sp2=c(1,2,3),
                   nest_time=c(1,2,2),ntime=19,f1t_int=FALSE)
sptsaranovaar1_rest <- psar(form5,data=unemp_it,sar=TRUE,ar1=TRUE,Wsp=Wsp_it,
                    control=list(thr=1e-1,maxit=200))
summary(sptsaranovaar1_rest)

## ------------------------------------------------------------------------
anova(geospsaranova,sptanova,sptsaranovaar1,sptsaranovaar1_rest)

## ---- eval=FALSE---------------------------------------------------------
 time_trend <- plot_timetrend(sptsarfit=sptsaranovaar1_rest,data=unemp_it,
                              time="year",spat="name",
                              xlab="Time",ylab="Time Trend",
                              title="Non-Parametric Time Trend by Region")

## ---- eval=FALSE---------------------------------------------------------
 spttrend_all <- fit_terms(sptsaranovaar1,"spttrend")
 unemp_it$spttrend_anovasarar1 <- spttrend_all$fitted_terms[,c("spttrend")]
 spttrend_t1 <- unemp_it$spttrend_anovasarar1[unemp_it$year=="1996"]
 spttrend_tf <- unemp_it$spttrend_anovasarar1[unemp_it$year=="2014"]
 nint <- 5
 int_spttrend_t1 <- classIntervals(spttrend_t1,nint,"equal")
 int_spttrend_tf<- classIntervals(spttrend_tf,nint,style="fixed")
 library(classInt); library(maptools)
 breaks_int_spttrend_t1 <- round(int_spttrend_t1$brks,1)
 multicol <- colorRampPalette(c("yellow","red"))
 colores <- multicol(nint)
 col_t1 <- findColours(int_spttrend_t1,colores)
 par(mfrow=c(1,2))
 par(mar=c(0.2,0.2,1.5,0))
 x  <- readShapePoly("~/Data/Prov2001_WGS84",IDvar="COD_PRO")
## # Read polygon shape files into SpatialPolygonsDataFrame objects
 coord <- coordinates(x)
 plot(x, border="black",col=col_t1,xlim=NULL,axes=FALSE,
      main="Spat. Trend 1996")
 leyenda <- leglabs(breaks_int_spttrend_t1,
                    under="under",
                    over="over",between="to")
 legend('topright',legend=leyenda,fill=colores,cex=0.9,
        pt.cex=cex,title="Intervals",bty="n")

 col_tf <- findColours(int_spttrend_tf,colores)
 plot(x, border="black",col=col_tf,xlim=NULL,axes=FALSE,
      main="Spat. Trend 2014")

## ------------------------------------------------------------------------
library(plm)
pdataframe <- pdata.frame(unemp_it,index=c("prov","year"))
pdataframe$resids_geospsaranova <- geospsaranova$residuals
pdataframe$resids_sptanova <- sptanova$residuals
pdataframe$resids_sptsaranova <- sptsaranova$residuals
pdataframe$resids_sptsaranovaar1 <- sptsaranovaar1$residuals
pcdtest(pdataframe$resids_geospsaranova)
pcdtest(pdataframe$resids_sptanova)
pcdtest(pdataframe$resids_sptsaranova)
pcdtest(pdataframe$resids_sptsaranovaar1)

## ---- echo=FALSE---------------------------------------------------------
library(car)
source("serial_correlation_test.r")
fe <- plm(unrate  ~ empgrowth+partrate+agri+cons+serv,
          data = pdataframe, model = "within", effect = "individual")
FEres <- resid(fe)
data <- model.frame(fe)
attr(FEres,"data") <- NULL
N <- length(FEres)
FEres.1 <- c(NA,FEres[1:(N-1)])
index <- attr(data, "index")
id1 <- index[[1]]
id2 <- index[[2]]
lagid <- as.numeric(id1)-c(NA,as.numeric(id1)[1:(N-1)])

## ------------------------------------------------------------------------
rho.H0 <- 0
my.pwartest(pdataframe$resids_geospsaranova,N,id1,id2,rho.H0)
my.pwartest(pdataframe$resids_sptanova,N,id1,id2,rho.H0)
my.pwartest(pdataframe$resids_sptsaranova,N,id1,id2,rho.H0)
my.pwartest(pdataframe$resids_sptsaranovaar1,N,id1,id2,rho.H0)
pdataframe$residsnorm_sptsaranovaar1 <- sptsaranovaar1$residuals_norm
my.pwartest(pdataframe$residsnorm_sptsaranovaar1,N,id1,id2,rho.H0)

